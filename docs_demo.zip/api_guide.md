## Weather API
The fetch weather function retrieves global weather data using the official API.