# Project Overview
This project handles user login and data statistics calculations.