def calculate_statistics(data):
    # Compute mean and standard deviation
    import numpy as np
    return np.mean(data), np.std(data)