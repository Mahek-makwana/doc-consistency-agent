def fetch_weather(city):
    import requests
    return requests.get(f'https://api.weather.com/{city}').json()