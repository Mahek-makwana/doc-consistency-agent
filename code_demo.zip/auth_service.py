def login(user, pwd):
    # Authenticate via database
    return verify_credentials(user, pwd)